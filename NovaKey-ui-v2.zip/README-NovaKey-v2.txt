NOVАKEY UI V2

1. Tải index.html lên repo Education00/Huu-anh và ghi đè file index.html cũ.
2. Vào Firebase Console > Firestore Database > Rules.
3. Dán nội dung firestore.rules rồi bấm Publish.
4. Mở trang admin: https://education00.github.io/Huu-anh/?admin=1
5. Vào Kho tài khoản, thêm tài khoản và bấm "Đồng bộ số lượng công khai".
6. Vào Cấu hình để nhập ngân hàng/BIN, số tài khoản, chủ tài khoản và Zalo.

Lưu ý: QR và nội dung chuyển khoản riêng đã có. Muốn tự cộng tiền ngân hàng hoàn toàn cần kết nối webhook/API biến động số dư ở backend; không thể làm an toàn chỉ bằng GitHub Pages.
